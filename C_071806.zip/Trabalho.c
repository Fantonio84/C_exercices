#include <stdio.h>

int main()
{

    float produtos[7][5] = {
        {1.0, 0, 118.70, 0, 0},
        {2.0, 0, 95.80, 0, 0},
        {3.0, 0, 83.50, 0, 0},
        {4.0, 0, 60, 0, 0},
        {5.0, 0, 23, 0, 0},
        {6.0, 0, 15, 0, 0},
        {7.0, 0, 3.80, 0, 0},
        {8.0, 0, 1.70, 0, 0}};

    int i, j, x,codProduto,quantidadeVendida;
    x = 1;

    do
    {
        printf("Informe o codigo do %d produto  : " , x);
        scanf("%d", &codProduto);
        if(codProduto !=0)
        {
        printf("Informe a quantidade vendida do %d produto  : " , x);
        scanf("%d", &quantidadeVendida);
        }
        x++;

        produtos[codProduto-1][1] = quantidadeVendida;
        

    } while (codProduto != 0);

     for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 5; j++)
        {
            printf("%f ", produtos[i][j]);
        }
        printf("\n");
    }


    return 0;
}
